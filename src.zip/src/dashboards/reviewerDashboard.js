import './dashboard.css'

export default function ReviewerDashboard() {
    return (
      <div className="main">
        <h1> Reviewer Dashboard</h1>
      </div>
    );
  }