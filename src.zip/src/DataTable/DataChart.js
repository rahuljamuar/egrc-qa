import { useState } from "react";

export default function DataChart() {
  const [fileChoose, setFileChosed] = useState([]);
  const [notifyLargeFile, setNotifyLargeFile] = useState(true);
  const [ownerDropdown, setOwnerDropdown] = useState(false);
  const [adminDropdown, setAdminDropdown] = useState(false);
  const [reviewerDropdown, setReviewerDropdown] = useState(false);

  const handleOwnerDropdown = () => {
    setOwnerDropdown(!ownerDropdown);
  };
  const handleAdminDropdown = () => {
    setAdminDropdown(!adminDropdown);
  };
  const handleReviewerDropdown = () => {
    setReviewerDropdown(!reviewerDropdown);
  };

  const readFile = (e) => {
    e.preventDefault();
    const files = e.target.files;
    let uploads = [...fileChoose];
    for (let i = 0; i < files.length; i++) {
      if (files[i].size <= 20971520) {
        uploads.push(files[i]);
      } else {
        setNotifyLargeFile(!notifyLargeFile);
      }
    }
    setFileChosed(uploads);
    e.target.value = "";
  };

  const deleteFile = (deleteFile) => {
    //e.preventDefault();
    let uploads = [...fileChoose];
    for (let i = 0; i < uploads.length; i++) {
      if (deleteFile === uploads[i]) {
        uploads.splice(i, 1);
      }
    }
    setFileChosed(uploads);
  };
  return (
    <div>
      <ul class="mt-6 flex">
  <li class="-mb-px mr-0">
    <a class=" text-darkblue1 text-xl text-decoration-line: underline underline-offset-8 inline-block  py-2 px-0.5 text-blue-700 font-bold" href="#">Insert</a>
  </li>
  <li class="mr-0">
    <a class=" inline-block py-2 px-4 text-xl text-blue-500 hover:text-blue-800 font-bold" href="#">Create</a>
  </li>
</ul>
      <div>
        <div className="pt-4">
          <div id="FileUpload" className="w-full">
            <label className="flex relative justify-center w-full h-28 px-4 transition bg-white border-2 border-buttonblue border-dashed rounded-md appearance-none hover:border-gray-400 focus:outline-none">
              <input
                type="file"
                id="upload"
                onChange={readFile}
                multiple
                className="font-medium text-buttonblue cursor-pointer w-full"
              />
              <span className="flex items-center space-x-2 absolute top-10">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-6 h-6 text-slate"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  stroke-width="2"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                  />
                </svg>
                <span className="text-darkblue1 font-bold">
                  Click to upload
                  <span className="text-black"> or drag and drop</span>
                </span>
              </span>

            </label>
            
           

            {fileChoose &&
              fileChoose.map((file) => (
                <div className="flex my-4 p-4 w-full bg-lightblue3 text-black rounded-lg shadow-xl justify-between">
                  <div className="flex items-center">
                    <div className="flex flex-col">
                      <p className="font-bold flex items-center">
                        <i className="px-4 bx bx-file-blank text-2xl"></i>
                        {file?.name}
                      </p>
                      <p className="ml-14">
                        {Math.round(file?.size / 1024)} kb
                      </p>
                    </div>
                  </div>
                  <div className="flex text-white">
                    <div className="mr-4">
                      <i
                        className="mt-4 hover:cursor-pointer text-black  hover:text-yesgreen"
                        onClick={() => window.open(file, "")}
                      ></i>
                    </div>

                    <div
                      className="mr-2 hover:cursor-pointer text-black  hover:text-nored"
                      onClick={() => deleteFile(file)}
                    >
                      <i className="mt-4 bx bxs-trash"></i>
                    </div>
                  </div>
                </div>
              ))}
               <button class="flex w-full mt-4 justify-center bg-darkblue1 hover:bg-darkblue1 text-white font-bold py-2 px-4 border-b-4 border-darkblue2 hover:border-darkblue2 rounded">
  Button
</button>
          </div>
        </div>
      </div>
      <div className="mt-8 w-full flex justify-between">
        <div className="w-2/3 flex space-x-6">
       
          <div className="relative inline-block text-left">
          
            <div>
                
            <div>
              <p className="text-xl font-bold mb-2">Filter</p>
            </div>
              <button
                type="button"
                className="inline-flex justify-between w-56 rounded-3xl border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50"
                id="menu-button"
                aria-expanded="true"
                aria-haspopup="true"
                onClick={handleOwnerDropdown}
              >
                Owner
                <svg
                  className="-mr-1 ml-2 h-5 w-5"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"
                  />
                </svg>
              </button>
            </div>

            <div
              className={`${
                ownerDropdown === false ? "hidden" : ""
              } origin-top-right absolute right-35 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none`}
              role="menu"
              aria-orientation="vertical"
              aria-labelledby="menu-button"
              tabindex="-1"
            >
              <div className="py-1" role="none">
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-0"
                >
                  Account settings
                </a>
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-1"
                >
                  Support
                </a>
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-2"
                >
                  License
                </a>
                <form method="POST" action="#" role="none">
                  <button
                    type="submit"
                    className="text-gray-700 block w-full text-left px-4 py-2 text-sm"
                    role="menuitem"
                    tabindex="-1"
                    id="menu-item-3"
                  >
                    Sign out
                  </button>
                </form>
              </div>
            </div>
          </div>
          <div className="relative inline-block text-left mt-9">
            <div>
              <button
                type="button"
                className="inline-flex justify-between w-56 rounded-3xl border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50"
                id="menu-button"
                aria-expanded="true"
                aria-haspopup="true"
                onClick={handleReviewerDropdown}
              >
                Reviewer
                <svg
                  className="-mr-1 ml-2 h-5 w-5"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"
                  />
                </svg>
              </button>
            </div>

            <div
              className={`${
                reviewerDropdown === false ? "hidden" : ""
              } origin-top-right absolute right-35 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none`}
              role="menu"
              aria-orientation="vertical"
              aria-labelledby="menu-button"
              tabindex="-1"
            >
              <div className="py-1" role="none">
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-0"
                >
                  Account settings
                </a>
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-1"
                >
                  Support
                </a>
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-2"
                >
                  License
                </a>
                <form method="POST" action="#" role="none">
                  <button
                    type="submit"
                    className="text-gray-700 block w-full text-left px-4 py-2 text-sm"
                    role="menuitem"
                    tabindex="-1"
                    id="menu-item-3"
                  >
                    Sign out
                  </button>
                </form>
              </div>
            </div>
          </div>
          <div className="relative inline-block text-left mt-9">
            <div>
              <button
                type="button"
                className="inline-flex justify-between w-56 rounded-3xl border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50"
                id="menu-button"
                aria-expanded="true"
                aria-haspopup="true"
                onClick={handleAdminDropdown}
              >
                Admin
                <svg
                  className="-mr-1 ml-2 h-5 w-5"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path
                    fill-rule="evenodd"
                    d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                    clip-rule="evenodd"
                  />
                </svg>
              </button>
            </div>

            <div
              className={`${
                adminDropdown === false ? "hidden" : ""
              } origin-top-right absolute right-35 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none`}
              role="menu"
              aria-orientation="vertical"
              aria-labelledby="menu-button"
              tabindex="-1"
            >
              <div className="py-1" role="none">
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-0"
                >
                  Account settings
                </a>
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-1"
                >
                  Support
                </a>
                <a
                  href="#!"
                  className="text-gray-700 block px-4 py-2 text-sm"
                  role="menuitem"
                  tabindex="-1"
                  id="menu-item-2"
                >
                  License
                </a>
                <form method="POST" action="#" role="none">
                  <button
                    type="submit"
                    className="text-gray-700 block w-full text-left px-4 py-2 text-sm"
                    role="menuitem"
                    tabindex="-1"
                    id="menu-item-3"
                  >
                    Sign out
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="w-1/3 mt-9">
          <button
            type="button"
            id="bt"
            className="w-40 block ml-2 mr-auto md:mr-auto mt-4 xl:mt-0 bg-buttonblue xl:mr-auto text-white py-2.5 px-3 rounded-3xl active:bg-darkblue2 hover:shadow-lg transition duration-150 ease-in-out"
          >
            Apply
          </button>
        </div>
      </div>
      <div className="mt-8 w-full flex">
        <div className="w-2/3"></div>
        <div className="w-1/3">
        <button class="bg-gray w-40 hover:bg-gray-400 ml-2 mr-auto md:mr-auto text-gray-800 font-bold py-2.5 px-6 rounded-3xl inline-flex items-center">
  <svg class="fill-current w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M13 8V2H7v6H2l8 8 8-8h-5zM0 18h20v2H0v-2z"/></svg>
  <span> Download </span>
</button>
        </div>
      </div>
    </div>
  );
}
