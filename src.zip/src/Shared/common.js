export const baseUrl={
    local:'https://egrc-server-dev.azurewebsites.net/api',
}

export const env={
    environment:'dev'
}