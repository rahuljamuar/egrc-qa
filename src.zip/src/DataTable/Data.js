import React, {useEffect } from "react";
import DataTable from "./DataTableSide";
import DataChart from "./DataChart";
import { useRecoilState } from "recoil";
import { sideNavState } from "../atoms/sideNavState";


export default function Data() {
  const [isOpen, setIsOpen] = useRecoilState(sideNavState);

  useEffect(() => {
    document.body.style.zoom = "85%";
  }, []);

  return (
    <div className="flex">
      <div className="absolute w-1/2 lg:w-[35%] 2xl:w-[24%] bg-lightblue overflow-y-auto">
        <DataTable />
      </div>
      <div
        className={`${
          isOpen === false
            ? "left-[59%] xl:left-[40%] 2xl:left-[29%] lg:w-[60%] 2xl:w-[70%]"
            : "left-[45%] xl:left-[33%] 2xl:left-[24%] lg:w-[69%] 2xl:w-[76%] "
        } w-1/2 px-14  fixed h-full overflow-y-auto`}
      >
        <DataChart />
      </div>
    </div>
  );
}
