import './dashboard.css'

export default function AdminDashboard() {
    return (
      <div className="main">
        <h1>Admin Dashboard</h1>
      </div>
    );
  }