import './dashboard.css'

export default function OwnerDashboard() {
    return (
      <div className="main">
        <h1 className='text'>Owner Dashboard</h1>
      </div>
    );
  }