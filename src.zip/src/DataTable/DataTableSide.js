import { useState } from "react";

export default function DataTable(props) {
  const [show, setShow] = useState(true);
  const [isVisible, setIsVisible] = useState(false);

  const Visibilitytoggle = () => {
    setIsVisible(!isVisible);
  };


  return (
    <div className="pb-10 w-100" style={{ minHeight: "185vh", height: "auto" }}>
      <div className="">
      <div className="pt-8 pl-8 text-left">
        <p className="text-3xl font-bold">
          Hi, Snehal{" "}
          {props?.userData?.control_owner &&
            props?.userData?.control_owner.split(" ")[0]}
        </p>
        <p className="pt-1 text-md font-normal text-slate">(Owner)</p>
      </div>
        <div
          className={
            isVisible === true
              ? "pt-4 mb-2 pb-2 pl-8 bg-darkblue1 text-white"
              : "pt-4 mb-2 pb-2 pl-8 bg-lightblue2 hover:bg-darkblue1 hover:text-white"
          }
          onClick={Visibilitytoggle}
        >
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className={isVisible === true ? "" : "hidden"}>
            <div className="">
              <p className="pt-2 font-semibold">Data Description</p>
              <p className="pt-2 text-xs pr-6">trhghjgjhgj</p>
            </div>
            <div className="">
              <p className="pt-2 font-semibold">Additional Data </p>
            </div>
          </div>
        </div>
        <div
          className={
            isVisible === true
              ? "pt-4 mb-2 pb-2 pl-8 bg-darkblue1 text-white"
              : "pt-4 mb-2 pb-2 pl-8 bg-lightblue2 hover:bg-darkblue1 hover:text-white"
          }
          onClick={Visibilitytoggle}
        >
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className={isVisible === true ? "" : "hidden"}>
            <div className="">
              <p className="pt-2 font-semibold">Data Description</p>
              <p className="pt-2 text-xs pr-6">trhghjgjhgj</p>
            </div>
            <div className="">
              <p className="pt-2 font-semibold">Additional Data </p>
            </div>
          </div>
        </div>
        <div
          className={
            isVisible === true
              ? "pt-4 mb-2 pb-2 pl-8 bg-darkblue1 text-white"
              : "pt-4 mb-2 pb-2 pl-8 bg-lightblue2 hover:bg-darkblue1 hover:text-white"
          }
          onClick={Visibilitytoggle}
        >
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className={isVisible === true ? "" : "hidden"}>
            <div className="">
              <p className="pt-2 font-semibold">Data Description</p>
              <p className="pt-2 text-xs pr-6">trhghjgjhgj</p>
            </div>
            <div className="">
              <p className="pt-2 font-semibold">Additional Data </p>
            </div>
          </div>
        </div>
        <div
          className={
            isVisible === true
              ? "pt-4 mb-2 pb-2 pl-8 bg-darkblue1 text-white"
              : "pt-4 mb-2 pb-2 pl-8 bg-lightblue2 hover:bg-darkblue1 hover:text-white"
          }
          onClick={Visibilitytoggle}
        >
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className="pt-2 flex md:flex-row xl:flex-row flex-col ">
            <p className="">Data</p>
            <p className="pl-7 font-bold -ml-7 md:ml-0 xl:ml-0 md:flex-row xl:flex-row flex-col">
              Data Table
            </p>
          </div>
          <div className={isVisible === true ? "" : "hidden"}>
            <div className="">
              <p className="pt-2 font-semibold">Data Description</p>
              <p className="pt-2 text-xs pr-6">trhghjgjhgj</p>
            </div>
            <div className="">
              <p className="pt-2 font-semibold">Additional Data </p>
            </div>
          </div>
        </div>


      </div>
    </div>
  );
}
